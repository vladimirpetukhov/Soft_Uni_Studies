﻿namespace BarraksWars.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
