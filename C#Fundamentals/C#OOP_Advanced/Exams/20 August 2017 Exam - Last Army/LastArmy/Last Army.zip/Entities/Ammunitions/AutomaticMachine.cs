﻿public class AutomaticMachine : Ammunition
{
    public const double WeightPoint = 6.3;

    public AutomaticMachine(string name)
        : base(name, WeightPoint)
    {
    }
}