﻿public class RPG : Ammunition
{
    public const double WeightPoint = 17.1;

    public RPG(string name)
        : base(name, WeightPoint)
    {
    }
}