﻿namespace _05.KingsGambitExtended.Contracts
{
    public interface IHuman
    {
        string Name { get; }
    }
}
