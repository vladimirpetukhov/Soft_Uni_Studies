﻿public interface IExecute
{
    string Execute();
}

