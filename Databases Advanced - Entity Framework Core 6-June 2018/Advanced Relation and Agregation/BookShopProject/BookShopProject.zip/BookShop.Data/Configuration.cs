﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString =>
          "Server=DESKTOP-8DBTK91\\SQLEXPRESS02;Database=BillsPaymentSystem;Integrated Security = True";
    }
}
