﻿namespace BarraksWars.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {

    }
}
