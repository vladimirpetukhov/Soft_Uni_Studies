﻿using System;


public interface IReader
{
    string ReadInput();
}

