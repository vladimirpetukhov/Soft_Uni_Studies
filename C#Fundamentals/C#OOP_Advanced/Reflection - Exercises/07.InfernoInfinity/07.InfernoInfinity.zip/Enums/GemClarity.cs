﻿namespace _07.InfernoInfinity.Enums
{
    public enum GemClarity
    {
        Chipped = 1,
        Regular = 2,
        Perfect = 5,
        Flawless = 10
    }
}
