﻿namespace BarraksWars.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
