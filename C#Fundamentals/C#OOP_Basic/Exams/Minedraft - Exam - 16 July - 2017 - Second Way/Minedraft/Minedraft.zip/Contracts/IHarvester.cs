﻿public interface IHarvester:IUnit
{
    double OreOutput { get; }
    double EnergyRequirement { get; }
}

