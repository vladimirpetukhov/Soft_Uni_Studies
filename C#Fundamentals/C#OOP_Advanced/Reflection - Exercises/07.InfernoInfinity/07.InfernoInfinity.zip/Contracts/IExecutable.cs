﻿namespace _07.InfernoInfinity.Contracts
{
    public interface IExecutable
    {
        void Execute();
    }
}
