﻿namespace BookShop
{
    using BookShop.Data;
    using BookShop.Initializer;
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main()
        {
            using (var db = new BookShopContext())
            {

                //DbInitializer.ResetDatabase(db);
                Console.WriteLine(GetBooksByAgeRestriction(db));// 1. Age Restriction
            }

        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string targetAgeGroup = null)
        {
            if (targetAgeGroup == null)
            {
                targetAgeGroup = Console.ReadLine();
            }

            return string.Join(Environment.NewLine, context.Books
                .Where(b => b.AgeRestriction.ToString().Equals(targetAgeGroup, StringComparison.OrdinalIgnoreCase))
                .Select(b => b.Title)
                .OrderBy(t => t));
        }
    }
}
