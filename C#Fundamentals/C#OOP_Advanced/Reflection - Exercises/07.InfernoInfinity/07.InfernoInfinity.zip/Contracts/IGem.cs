﻿namespace _07.InfernoInfinity.Contracts
{
    public interface IGem
    {
        int AddBonusToMinDamage();

        int AddBonusToMaxDamage();
    }
}
