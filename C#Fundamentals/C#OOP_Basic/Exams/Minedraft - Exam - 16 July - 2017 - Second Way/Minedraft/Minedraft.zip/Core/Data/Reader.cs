﻿using System;
public class Reader : IReader
{
   
    public string ReadInput()
    {
        return Console.ReadLine();
    }
}

