﻿
using System;

[AttributeUsage(AttributeTargets.Field)]
public class SonicHarvesterAttribute : Attribute
{
}

