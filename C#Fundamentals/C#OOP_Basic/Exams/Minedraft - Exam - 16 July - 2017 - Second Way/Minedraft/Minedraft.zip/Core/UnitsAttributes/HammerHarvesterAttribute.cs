﻿using System;

public class HammerHarvesterAttribute:Attribute
{
}

