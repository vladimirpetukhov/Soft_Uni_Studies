﻿public interface IUnit
{
    string Id { get; }
}

